var app = angular.module('app', ['ngRoute']);
app.config(['$httpProvider', '$routeProvider', function ($httpProvider, $routeProvider) {
    $routeProvider
      .when("/ebs", {
        templateUrl: "app/ebs/ebs.html",
        css:"app/ebs/ebs.css",
        controller:"ebs-controller"
      })
      .when("/admin", {
        templateUrl: "app/admin/admin.html",
        css:"app/admin/admin.css",
        controller:"admin-controller"
      })
      .when("", {
        templateUrl: ""
      });
  }]);