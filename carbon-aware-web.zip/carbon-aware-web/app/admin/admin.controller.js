app.controller('admin-controller', function ($scope, $location, $http) {
	console.log("test");
	$scope.loadingText = "";
	$scope.rewardPoint = 23;
    $scope.getEmission = function(loc){
		if(loc=='eastus'){
			return "34";
		}
		if(loc=='southcentralus'){
			return "217";
		}
		if(loc=='australiaeast'){
			return "300";
		}
    }

	$scope.changeServer = function(){
		$scope.rewardPoint=$scope.rewardPoint+12;
		setTimeout(function () {
			$scope.loadingText = "running...";
		  }, 2000);
	}
});