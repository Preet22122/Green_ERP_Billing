app.controller('ebs-controller', function ($scope, $location, $rootScope) {
	$scope.rewardPoint=12;
	$scope.loadingText = "";
	$scope.increaseReward = function(){
		$scope.rewardPoint+=7;
		setTimeout(function () {
			$scope.loadingText = "running...";
		  }, 2000);
	}
});