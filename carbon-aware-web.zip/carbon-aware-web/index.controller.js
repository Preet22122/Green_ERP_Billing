app.controller('index-controller', function ($scope, $location, $rootScope) {
	$rootScope.$on('$routeChangeStart', function () {
		$scope.setActive = function (tab) {
			if ($location.path().indexOf(tab) > 0) {
				return "active";
			}
		}
	});
});